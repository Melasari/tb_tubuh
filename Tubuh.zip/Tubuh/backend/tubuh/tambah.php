<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		//Mendapatkan Nilai Variable
		$name = $_POST['name'];
		$sifat = $_POST['sifat'];
		$jenis = $_POST['jenis'];
		
		//Pembuatan Syntax SQL
		$sql = "INSERT INTO tb_tubuh (nama,sifat,jenis) VALUES ('$name','$sifat','$jenis')";
		
		//Import File Koneksi database
		require_once('koneksi.php');
		
		//Eksekusi Query database
		if(mysqli_query($con,$sql)){
			echo 'Berhasil Menambahkan Tubuh';
		}else{
			echo 'Gagal Menambahkan Tubuh';
		}
		
		mysqli_close($con);
	}
?>
package com.nia.tubuh;

public class konfigurasi {

    public static final String URL_ADD = "http://192.168.43.139/tubuh/tambah.php";
    public static final String URL_GET_ALL = "http://192.168.43.139/tubuh/tampilanSemua.php";
    public static final String URL_GET_EMP = "http://192.168.43.139/tubuh/tampilOs.php";
    public static final String URL_UPDATE_EMP = "http://192.168.43.139/android/mahasiswa/updateMhs.php";
    public static final String URL_DELETE_EMP = "http://192.168.43.139/android/mahasiswa/hapusMhs.php?id=5";
    //
    public static final String URL_GET_SUKA = "http://192.168.43.139/android/mahasiswa/tampilsukaan.php";
    //catatan : hapus mahasiswa harus mengganti nomor id di belakang hapusMhs.php
    //php7 wagu sung

    public static final String KEY_EMP_KODE = "kode";
    public static final String KEY_EMP_NAMA = "name";
    public static final String KEY_EMP_SIFAT = "sifat";
    public static final String KEY_EMP_JENIS = "jenis";


    //
    public static final String KEY_ID = "id";
    public static final String KEY_SUKA = "suka";

    public static final String TAG_Id = "id";
    public static final String TAG_SUKA = "suka";

    public static final String TAG_JSON_ARRAY = "result";
    public static final String TAG_KODE = "kode";
    public static final String TAG_NAMA = "name";
    public static final String TAG_SIFAT = "sifat";
    public static final String TAG_JENIS = "jenis";


    public static final String EMP_ID = "emp_id";

    //192.168.43.139 oppokoe
    //172.12.8.212 informatika
    //192.168.100.35 warjok
    //192.168.100.19 bankjateng
}

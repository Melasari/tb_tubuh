package com.nia.tubuh;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextSifat;
    private EditText editTextJenis;


    TextInputLayout textInputLayoutNama;
    TextInputLayout textInputLayoutSIfat;
    TextInputLayout textInputLayoutJenis;


    private Button buttonAdd;
    private Button buttonView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = (EditText)findViewById(R.id.etNama);
        editTextSifat = (EditText)findViewById(R.id.etSifat);
        editTextJenis = (EditText)findViewById(R.id.etJenis);


        buttonAdd = (Button)findViewById(R.id.btnSimpan);
        buttonView = (Button)findViewById(R.id.btnLihat);

//        buttonAdd.setOnClickListener(this);
//        buttonView.setOnClickListener(this);

        setTitle("Cread");

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editTextName.getText().toString().length()==0){
                    //jika form Email belum di isi / masih kosong
                    editTextName.setError("Nama diperlukan!");
                }else if(editTextSifat.getText().toString().length()==0){
                    //jika form Passwrod belum di isi / masih kosong
                    editTextSifat.setError("Sifat diperlukan!");
                }else if(editTextJenis.getText().toString().length()==0){
                    //jika form Username belum di isi / masih kosong
                    editTextJenis.setError("Jenis diperlukan!");
                }else {
                    //jika form sudah terisi semua
                    addEmployee();
                }
            }
        });

        buttonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(getApplicationContext(), LihatActivity.class);
                startActivity(a);
            }
        });
    }

    private void addEmployee(){
        final String name = editTextName.getText().toString().trim();
        final String sifat = editTextSifat.getText().toString().trim();
        final String jenis = editTextJenis.getText().toString().trim();


        class AddEmployee extends AsyncTask<Void, Void, String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(MainActivity.this, "Menambahkan...", "Tunggu...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... voids) {
                HashMap<String, String> params = new HashMap<>();
                params.put(konfigurasi.KEY_EMP_NAMA, name);
                params.put(konfigurasi.KEY_EMP_SIFAT, sifat);
                params.put(konfigurasi.KEY_EMP_JENIS, jenis);


                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(konfigurasi.URL_ADD, params);
                return res;
            }
        }
        AddEmployee ae = new AddEmployee();
        ae.execute();
    }
}
